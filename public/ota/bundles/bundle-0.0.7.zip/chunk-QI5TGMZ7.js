var n={production:!0,apiUrl:"https://brahmadev-api.democompany.in.net"};export{n as a};
